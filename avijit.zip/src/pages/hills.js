import React from 'react';

export default function Hills () {
	return (
		<div
			style={{
				display: 'flex',
				justifyContent: 'Right',
				alignItems: 'Right',
				height: '100vh'
			}}
		>
			<h1>Hills</h1>
		</div>
	);
};

// export default Hills;
