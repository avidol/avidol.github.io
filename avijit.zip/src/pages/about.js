import React from 'react';

export default function About() {
	return (
		<div
			style={{
				display: 'flex',
				justifyContent: 'Right',
				alignItems: 'Right',
				height: '100vh'
			}}
		>
			<h1>Welcome to About</h1>
		</div>
	);
};

